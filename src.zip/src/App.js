import React, { Fragment } from 'react';
import './App.css';
import Login from './components/Login';

const App = () => {
  return (
    <Fragment>
      <Login />
    </Fragment>
  );
};

export default App;
