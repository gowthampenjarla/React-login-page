import React, { Component } from 'react';
import Alert from './Alert';

export class Login extends Component {
  state = {
    email: '',
    password: '',
    alert: null
  };

  onChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  onSubmit = e => {
    e.preventDefault();
    const user = {
      email: this.state.email,
      password: this.state.password
    };
    if (user.email === '' || user.password === '') {
      this.showAlert();
    }
  };

  showAlert() {
    this.setState({
      alert: {
        msg: 'UserName or Password Must not be null',
        type: 'danger'
      }
    });
    setTimeout(() => this.setState({ alert: null }), 3000);
  }
  render() {
    return (
      <div>
        <div className='container'>
          <Alert alert={this.state.alert} />
          <form
            className='needs-validation mt-5'
            onSubmit={this.onSubmit}
            novalidate
          >
            <div className='form-group'>
              <label>Email address</label>{' '}
              <input
                type='email'
                name='email'
                placeholder='Email'
                value={this.state.email}
                onChange={this.onChange}
                className='form-control'
              />
              <span className='validity'></span>
              <div class='valid-feedback'>Valid</div>
              <div class='invalid-feedback'>a to z only (2 to 15 long)</div>
            </div>
            <div className='form-group'>
              <label>Password</label>
              <input
                type='password'
                name='password'
                placeholder='Password'
                pattern='/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])([a-zA-Z0-9])$/)'
                minLength='8'
                maxLength='12'
                value={this.state.password}
                className='form-control'
                onChange={this.onChange}
              />
              <small className='invalid'>
                The passowrd must have all the attributes
              </small>
            </div>

            <button type='submit' className='btn btn-primary'>
              Submit
            </button>
          </form>
        </div>
      </div>
    );
  }
}

export default Login;

//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');

//   return (
//     <div className='container'>
//       <form className='mt-5'>
//         <div className='form-group'>
//           <label>Email address</label>
//           <input
//             type='email'
//             name='text'
//             placeholder='Email'
//             value={email}
//             onChange={e => setEmail(e.target.value)}
//             className='form-control'
//           />
//           <small id='emailHelp' className='form-text text-muted'>
//             We'll never share your email with anyone else.
//           </small>
//         </div>
//         <div className='form-group'>
//           <label>Password</label>
//           <input
//             type='password'
//             name='password'
//             placeholder='Password'
//             value={password}
//             className='form-control'
//             onChange={e => setPassword(e.target.value)}
//           />
//         </div>

//         <button type='submit' className='btn btn-primary'>
//           Submit
//         </button>
//       </form>
//     </div>
//   );
